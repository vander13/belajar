Cara menjalankan 
1. Download Node.js
2. Download NPM
3. Pada folder ini jalankan perintah npm i
4. Ketika sudah selesai jalan kan perintah "node signaler.js"
5. Cek dengan membuka browser localhost:8080

Firebase 
email : projectrtc209@gmail.com
password : yogyakarta